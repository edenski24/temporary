import React from "react";
import {
  FileText,
  Rocket,
  RefreshCw,
  Smartphone,
  Server,
  Wrench,
} from "lucide-react";
import Reveal from "./Reveal";

// Services — no SEO offering (removed per request)
const services = [
  {
    icon: FileText,
    title: "Brochure Websites",
    text: "Clean multi-page sites that present your business, services, and story beautifully.",
  },
  {
    icon: Rocket,
    title: "Landing Pages",
    text: "High-converting single pages built to capture leads from your ads and promotions.",
  },
  {
    icon: RefreshCw,
    title: "Website Redesigns",
    text: "Give your tired old site a complete modern refresh — same domain, brand new look.",
  },
  {
    icon: Smartphone,
    title: "Mobile Optimisation",
    text: "Flawless on every screen size, because most of your customers are on their phones.",
  },
  {
    icon: Server,
    title: "Domain & Hosting Setup",
    text: "I handle the technical setup end-to-end — domain, hosting, SSL, the lot.",
  },
  {
    icon: Wrench,
    title: "Website Maintenance",
    text: "Optional ongoing care — updates, backups, and tweaks so your site stays healthy.",
    optional: true,
  },
];

export default function Services() {
  return (
    <section id="services" className="py-20 sm:py-28 bg-background">
      <div className="max-w-7xl mx-auto px-5 sm:px-8">
        <Reveal className="max-w-2xl">
          <span className="text-sm font-semibold text-red-500 uppercase tracking-wide">
            What I build
          </span>
          <h2 className="mt-3 text-3xl sm:text-4xl font-bold tracking-tight text-white font-heading">
            Services built for local businesses
          </h2>
          <p className="mt-4 text-lg text-slate-400 leading-relaxed">
            From a simple one-pager to a full redesign, here's what I offer —
            no bloated packages, just what your business actually needs.
          </p>
        </Reveal>

        <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {services.map((s, i) => (
            <Reveal key={s.title} delay={(i % 3) * 0.08}>
              <div className="group h-full bg-white/[0.03] hover:bg-white/[0.06] rounded-2xl p-6 border border-white/10 hover:border-red-600/40 transition-all duration-300">
                <div className="flex items-center justify-between">
                  <div className="w-12 h-12 rounded-xl bg-red-600 text-white flex items-center justify-center group-hover:scale-110 transition-transform">
                    <s.icon size={22} />
                  </div>
                  {s.optional && (
                    <span className="text-xs font-medium text-slate-500 bg-white/5 px-2 py-1 rounded-full">
                      Optional
                    </span>
                  )}
                </div>
                <h3 className="mt-5 font-semibold text-white text-lg">
                  {s.title}
                </h3>
                <p className="mt-2 text-sm text-slate-400 leading-relaxed">
                  {s.text}
                </p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}