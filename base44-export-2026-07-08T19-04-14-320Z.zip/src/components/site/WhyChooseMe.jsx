import React from "react";
import {
  Zap,
  Wallet,
  Smartphone,
  Palette,
  ShieldCheck,
  HeartHandshake,
} from "lucide-react";
import Reveal from "./Reveal";

// Why choose me — no SEO claim (removed per request)
const features = [
  { icon: Zap, title: "Fast turnaround", text: "Most projects go live quickly." },
  { icon: Wallet, title: "Affordable pricing", text: "Honest rates with no hidden fees." },
  { icon: Smartphone, title: "Mobile-first", text: "Designed for phones before desktops." },
  { icon: Palette, title: "Modern design", text: "Clean, premium, built to impress." },
  { icon: ShieldCheck, title: "Secure hosting", text: "SSL and reliable hosting included." },
  { icon: HeartHandshake, title: "Friendly support", text: "Real help from a real person, anytime." },
];

export default function WhyChooseMe() {
  return (
    <section id="why-me" className="py-20 sm:py-28 bg-black relative overflow-hidden">
      <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-red-600/15 blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-96 h-96 rounded-full bg-red-600/10 blur-3xl pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-5 sm:px-8">
        <div className="grid lg:grid-cols-12 gap-12 items-start">
          <Reveal className="lg:col-span-5">
            <span className="text-sm font-semibold text-red-500 uppercase tracking-wide">
              Why choose me
            </span>
            <h2 className="mt-3 text-3xl sm:text-4xl font-bold tracking-tight text-white font-heading">
              A freelancer who treats your business like my own
            </h2>
            <p className="mt-4 text-lg text-slate-400 leading-relaxed">
              You won't get passed between account managers or lost in a queue.
              I'm a single dedicated designer who handles everything from first
              call to launch — and beyond.
            </p>
            <a
              href="#contact"
              className="mt-8 inline-flex items-center gap-2 bg-red-600 hover:bg-red-500 text-white font-semibold px-6 py-3 rounded-full transition-all hover:-translate-y-0.5"
            >
              Work with me
            </a>
          </Reveal>

          <div className="lg:col-span-7 grid sm:grid-cols-2 gap-4">
            {features.map((f, i) => (
              <Reveal key={f.title} delay={(i % 2) * 0.1}>
                <div className="group h-full bg-white/[0.04] hover:bg-white/[0.08] backdrop-blur border border-white/10 rounded-2xl p-5 transition-all duration-300">
                  <div className="w-10 h-10 rounded-lg bg-red-600 text-white flex items-center justify-center group-hover:scale-110 transition-transform">
                    <f.icon size={18} />
                  </div>
                  <h3 className="mt-4 font-semibold text-white">{f.title}</h3>
                  <p className="mt-1 text-sm text-slate-400">{f.text}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}