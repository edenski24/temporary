import React, { useState } from "react";
import { Plus, Minus } from "lucide-react";
import Reveal from "./Reveal";

// FAQ — honest answers, no fabricated track record or price ranges
const faqs = [
  {
    q: "How long does it take?",
    a: "Most simple brochure sites are ready within about a week once I have your content and photos. Bigger projects take a little longer, and I'll always agree a clear timeline with you before we start.",
  },
  {
    q: "How much does it cost?",
    a: "Pricing depends on what your business needs — the number of pages, features, and how custom you want to go. I'll give you a single, fixed quote upfront with no surprises once we've had a quick chat about your project.",
  },
  {
    q: "Do you provide hosting?",
    a: "Yes. I handle the full technical setup — domain registration, hosting, and SSL security. You won't have to touch any of it; that side of things is entirely on me.",
  },
  {
    q: "Can you redesign my existing website?",
    a: "Absolutely. If your current site looks dated, loads slowly, or doesn't work well on mobile, I can give it a complete modern refresh while keeping your domain and brand intact.",
  },
  {
    q: "Will it work on phones?",
    a: "Every site I build is mobile-first — designed and tested on phones before anything else. The majority of your customers will visit on mobile, so it has to be flawless there.",
  },
];

function Item({ item }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="border-b border-white/10">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between gap-4 py-5 text-left group"
      >
        <span className="font-semibold text-white group-hover:text-red-500 transition-colors">
          {item.q}
        </span>
        <span className="flex-shrink-0 w-7 h-7 rounded-full bg-white/5 group-hover:bg-red-600/20 flex items-center justify-center text-slate-300 transition-colors">
          {open ? <Minus size={15} /> : <Plus size={15} />}
        </span>
      </button>
      <div
        className={`grid transition-all duration-300 ${
          open ? "grid-rows-[1fr] opacity-100 pb-5" : "grid-rows-[0fr] opacity-0"
        }`}
      >
        <p className="overflow-hidden text-slate-400 leading-relaxed">{item.a}</p>
      </div>
    </div>
  );
}

export default function FAQ() {
  return (
    <section id="faq" className="py-20 sm:py-28 bg-background">
      <div className="max-w-3xl mx-auto px-5 sm:px-8">
        <Reveal className="text-center">
          <span className="text-sm font-semibold text-red-500 uppercase tracking-wide">
            FAQ
          </span>
          <h2 className="mt-3 text-3xl sm:text-4xl font-bold tracking-tight text-white font-heading">
            Questions, answered
          </h2>
          <p className="mt-4 text-lg text-slate-400">
            Everything you might want to know before getting in touch.
          </p>
        </Reveal>

        <Reveal delay={0.1} className="mt-10">
          <div>
            {faqs.map((f) => (
              <Item key={f.q} item={f} />
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}