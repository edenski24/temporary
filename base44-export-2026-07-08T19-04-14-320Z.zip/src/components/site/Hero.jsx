import React from "react";
import { motion } from "framer-motion";
import { ArrowRight, ArrowDown } from "lucide-react";
import Reveal from "./Reveal";

// Hero — honest copy (no fabricated stats), black + red theme, CSS-built mockup (no stock imagery)
export default function Hero() {
  return (
    <section
      id="top"
      className="relative pt-32 pb-20 sm:pt-40 sm:pb-28 overflow-hidden bg-background"
    >
      {/* decorative glow */}
      <div className="absolute -top-40 -right-40 w-[500px] h-[500px] rounded-full bg-red-600/20 blur-3xl pointer-events-none" />
      <div className="absolute top-40 -left-40 w-[400px] h-[400px] rounded-full bg-red-500/10 blur-3xl pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-5 sm:px-8 grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
        <div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 bg-red-600/10 text-red-500 text-sm font-medium px-3 py-1.5 rounded-full border border-red-600/20"
          >
            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
            Web design for local businesses
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.05 }}
            className="mt-6 text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-white leading-[1.05] font-heading"
          >
            Get your business
            <br />
            online the right
            <span className="text-red-500"> way.</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.15 }}
            className="mt-6 text-lg text-slate-400 max-w-xl leading-relaxed"
          >
            I build clean, fast, mobile-friendly websites for local businesses
            — designed to look professional, build trust, and make it easy for
            customers to find and contact you.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.25 }}
            className="mt-8 flex flex-col sm:flex-row gap-3"
          >
            <a
              href="#contact"
              className="inline-flex items-center justify-center gap-2 bg-red-600 hover:bg-red-500 text-white font-semibold px-6 py-3.5 rounded-full transition-all hover:shadow-lg hover:shadow-red-600/25 hover:-translate-y-0.5"
            >
              Get a Free Quote
              <ArrowRight size={18} />
            </a>
            <a
              href="#why-website"
              className="inline-flex items-center justify-center gap-2 bg-white/5 hover:bg-white/10 text-white font-semibold px-6 py-3.5 rounded-full border border-white/15 transition-all hover:-translate-y-0.5"
            >
              Why You Need One
              <ArrowDown size={16} />
            </a>
          </motion.div>
        </div>

        {/* CSS browser mockup — crafted, on-brand, no stock imagery */}
        <Reveal delay={0.2}>
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-tr from-red-600/20 to-transparent rounded-3xl blur-2xl" />
            <div className="relative rounded-2xl overflow-hidden shadow-2xl shadow-black/50 border border-white/10 bg-[#0d0d0d]">
              {/* browser bar */}
              <div className="flex items-center gap-2 px-4 h-10 border-b border-white/10 bg-white/5">
                <span className="w-3 h-3 rounded-full bg-red-500/80" />
                <span className="w-3 h-3 rounded-full bg-slate-600" />
                <span className="w-3 h-3 rounded-full bg-slate-600" />
                <div className="ml-3 flex-1 h-5 rounded-md bg-white/5" />
              </div>
              {/* mock page content */}
              <div className="p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-md bg-red-600" />
                    <div className="h-3 w-16 rounded bg-white/20" />
                  </div>
                  <div className="flex gap-3">
                    <div className="h-2.5 w-10 rounded bg-white/10" />
                    <div className="h-2.5 w-10 rounded bg-white/10" />
                    <div className="h-2.5 w-10 rounded bg-white/10" />
                  </div>
                </div>
                <div className="pt-6 space-y-3">
                  <div className="h-6 w-3/4 rounded bg-white/15" />
                  <div className="h-6 w-1/2 rounded bg-red-600/60" />
                  <div className="h-2.5 w-full rounded bg-white/5" />
                  <div className="h-2.5 w-5/6 rounded bg-white/5" />
                </div>
                <div className="flex gap-3 pt-2">
                  <div className="h-8 w-24 rounded-full bg-red-600" />
                  <div className="h-8 w-24 rounded-full border border-white/15" />
                </div>
                <div className="grid grid-cols-3 gap-3 pt-4">
                  {[0, 1, 2].map((i) => (
                    <div
                      key={i}
                      className="rounded-xl border border-white/10 p-3 space-y-2"
                    >
                      <div className="h-6 w-6 rounded-md bg-white/10" />
                      <div className="h-2 w-full rounded bg-white/5" />
                      <div className="h-2 w-2/3 rounded bg-white/5" />
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* floating glass card */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.5 }}
              className="absolute -bottom-5 -left-5 sm:-left-8 bg-white/10 backdrop-blur-xl border border-white/15 rounded-2xl shadow-xl p-4 flex items-center gap-3"
            >
              <div className="w-10 h-10 rounded-xl bg-red-600 flex items-center justify-center text-white font-bold">
                ✓
              </div>
              <div>
                <div className="text-sm font-semibold text-white">
                  No-obligation quote
                </div>
                <div className="text-xs text-slate-400">Free & upfront</div>
              </div>
            </motion.div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}