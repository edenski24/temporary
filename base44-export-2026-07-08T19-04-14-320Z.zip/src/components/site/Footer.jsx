import React from "react";
import { Facebook, Instagram, Linkedin, Mail, Phone, MapPin } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-black text-slate-500 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-5 sm:px-8 py-14">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-10">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-8 h-8 rounded-lg bg-red-600 flex items-center justify-center text-white font-bold text-xs">
                LP
              </span>
              <span className="font-semibold tracking-tight text-white font-heading">
                Launch<span className="text-red-500">Point</span>
              </span>
            </div>
            <p className="mt-4 text-sm leading-relaxed max-w-xs">
              Modern websites for local businesses. Fast, affordable, and built
              to win you more customers. Built by LaunchPoint.
            </p>
            <div className="mt-5 flex gap-3">
              {[
                { icon: Facebook, label: "Facebook" },
                { icon: Instagram, label: "Instagram" },
                { icon: Linkedin, label: "LinkedIn" },
              ].map((s) => (
                <a
                  key={s.label}
                  href="#top"
                  aria-label={s.label}
                  className="w-9 h-9 rounded-lg bg-white/5 hover:bg-red-600 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
                >
                  <s.icon size={17} />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-semibold text-white text-sm">Explore</h4>
            <ul className="mt-4 space-y-2.5 text-sm">
              {[
                { label: "Why a Website", href: "#why-website" },
                { label: "Services", href: "#services" },
                { label: "Why Me", href: "#why-me" },
                { label: "Pricing", href: "#pricing" },
                { label: "FAQ", href: "#faq" },
              ].map((l) => (
                <li key={l.href}>
                  <a href={l.href} className="hover:text-white transition-colors">
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-white text-sm">Get in touch</h4>
            <ul className="mt-4 space-y-3 text-sm">
              <li>
                <a href="mailto:hello@studio.design" className="flex items-center gap-2.5 hover:text-white transition-colors">
                  <Mail size={16} className="text-red-500" />
                  hello@studio.design
                </a>
              </li>
              <li>
                <a href="tel:+441234567890" className="flex items-center gap-2.5 hover:text-white transition-colors">
                  <Phone size={16} className="text-red-500" />
                  01234 567 890
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <MapPin size={16} className="text-red-500" />
                Serving local businesses nationwide
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-white text-sm">Ready to start?</h4>
            <p className="mt-4 text-sm leading-relaxed">
              Get a free, no-obligation quote today.
            </p>
            <a
              href="#contact"
              className="mt-4 inline-flex items-center justify-center bg-red-600 hover:bg-red-500 text-white font-semibold text-sm px-5 py-2.5 rounded-full transition-colors"
            >
              Get a Free Quote
            </a>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-600">
          <p>© {new Date().getFullYear()} LaunchPoint. All rights reserved.</p>
          <div className="flex gap-5">
            <a href="#top" className="hover:text-white transition-colors">Privacy</a>
            <a href="#top" className="hover:text-white transition-colors">Terms</a>
          </div>
        </div>
      </div>
    </footer>
  );
}