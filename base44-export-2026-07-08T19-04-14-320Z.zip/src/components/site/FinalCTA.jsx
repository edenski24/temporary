import React, { useState } from "react";
import { ArrowRight, Check } from "lucide-react";
import Reveal from "./Reveal";

// Final CTA — contact form with validation (logic unchanged), dark + red theme
export default function FinalCTA() {
  const [form, setForm] = useState({ name: "", email: "", business: "", message: "" });
  const [errors, setErrors] = useState({});
  const [sent, setSent] = useState(false);

  const validate = () => {
    const e = {};
    if (!form.name.trim()) e.name = "Please enter your name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email))
      e.email = "Please enter a valid email address.";
    if (!form.business.trim()) e.business = "Please tell us your business name.";
    if (!form.message.trim()) e.message = "Tell me a little about what you need.";
    return e;
  };

  const onSubmit = (ev) => {
    ev.preventDefault();
    const e = validate();
    setErrors(e);
    if (Object.keys(e).length === 0) setSent(true);
  };

  const field = (name, label, type = "text", textarea = false) => (
    <div>
      <label className="block text-sm font-medium text-slate-300 mb-1.5">
        {label}
      </label>
      {textarea ? (
        <textarea
          rows={4}
          value={form[name]}
          onChange={(ev) => setForm({ ...form, [name]: ev.target.value })}
          className={`w-full rounded-xl border bg-white/5 px-4 py-2.5 text-white outline-none transition-colors ${
            errors[name] ? "border-red-500" : "border-white/10 focus:border-red-500"
          }`}
        />
      ) : (
        <input
          type={type}
          value={form[name]}
          onChange={(ev) => setForm({ ...form, [name]: ev.target.value })}
          className={`w-full rounded-xl border bg-white/5 px-4 py-2.5 text-white outline-none transition-colors ${
            errors[name] ? "border-red-500" : "border-white/10 focus:border-red-500"
          }`}
        />
      )}
      {errors[name] && (
        <p className="mt-1 text-xs text-red-400">{errors[name]}</p>
      )}
    </div>
  );

  return (
    <section id="contact" className="py-20 sm:py-28 bg-black relative overflow-hidden">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] rounded-full bg-red-600/20 blur-3xl pointer-events-none" />

      <div className="relative max-w-6xl mx-auto px-5 sm:px-8 grid lg:grid-cols-2 gap-12 items-center">
        <Reveal>
          <span className="text-sm font-semibold text-red-500 uppercase tracking-wide">
            Free quote
          </span>
          <h2 className="mt-3 text-3xl sm:text-4xl font-bold tracking-tight text-white font-heading">
            Let's get your business online
          </h2>
          <p className="mt-4 text-lg text-slate-400 leading-relaxed">
            Tell me about your business and what you're after. I'll get back to
            you with a free, no-obligation quote — no pushy sales, just honest
            advice.
          </p>
          <ul className="mt-6 space-y-2.5">
            {["No obligation, no pressure", "Clear, upfront pricing", "Friendly, honest advice"].map((b) => (
              <li key={b} className="flex items-center gap-2.5 text-slate-300">
                <span className="w-5 h-5 rounded-full bg-red-600 flex items-center justify-center flex-shrink-0">
                  <Check size={13} className="text-white" />
                </span>
                {b}
              </li>
            ))}
          </ul>
        </Reveal>

        <Reveal delay={0.15}>
          <div className="bg-white/[0.04] backdrop-blur rounded-2xl p-6 sm:p-8 border border-white/10 shadow-2xl">
            {sent ? (
              <div className="py-10 text-center">
                <div className="w-14 h-14 rounded-full bg-red-600/15 text-red-500 flex items-center justify-center mx-auto">
                  <Check size={28} />
                </div>
                <h3 className="mt-4 font-semibold text-lg text-white">
                  Thank you, {form.name.split(" ")[0]}!
                </h3>
                <p className="mt-2 text-slate-400">
                  Your request is in. I'll be in touch soon.
                </p>
              </div>
            ) : (
              <form onSubmit={onSubmit} className="space-y-4" noValidate>
                {field("name", "Your name")}
                {field("email", "Email address", "email")}
                {field("business", "Business name")}
                {field("message", "What do you need?", "text", true)}
                <button
                  type="submit"
                  className="w-full inline-flex items-center justify-center gap-2 bg-red-600 hover:bg-red-500 text-white font-semibold px-6 py-3.5 rounded-full transition-all hover:-translate-y-0.5"
                >
                  Get My Free Quote
                  <ArrowRight size={18} />
                </button>
              </form>
            )}
          </div>
        </Reveal>
      </div>
    </section>
  );
}