import React from "react";
import {
  Search,
  BadgeCheck,
  MessageSquare,
  Globe,
  Clock,
  TrendingUp,
} from "lucide-react";
import Reveal from "./Reveal";

// Why your business needs a website — the centerpiece section, expanded and honest
const reasons = [
  {
    icon: Search,
    title: "Customers search online first",
    text: "Before anyone walks through your door or picks up the phone, they look you up online. If they can't find you, they find someone else.",
  },
  {
    icon: BadgeCheck,
    title: "It builds instant credibility",
    text: "A clean, professional site tells people you're a real, established business they can trust. No website quietly costs you their confidence.",
  },
  {
    icon: MessageSquare,
    title: "Makes you easy to contact",
    text: "A contact form, tap-to-call number, and a map mean customers can reach you the moment they're ready — no digging through social DMs.",
  },
  {
    icon: Globe,
    title: "You actually own it",
    text: "Your website is the one place online you fully control. Algorithms change and platforms come and go — your site is always yours.",
  },
  {
    icon: Clock,
    title: "You're open 24/7",
    text: "A website works while you don't. It answers questions, shows your work, and captures enquiries at any hour of any day.",
  },
  {
    icon: TrendingUp,
    title: "You stand out from competitors",
    text: "Plenty of local businesses still rely on a Facebook page. A proper website instantly puts you a step ahead of every one of them.",
  },
];

export default function WhyWebsite() {
  return (
    <section
      id="why-website"
      className="py-20 sm:py-28 bg-card relative overflow-hidden"
    >
      <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-red-600/10 blur-3xl pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-5 sm:px-8">
        <div className="grid lg:grid-cols-12 gap-12 items-start">
          <Reveal className="lg:col-span-5 lg:sticky lg:top-28">
            <span className="text-sm font-semibold text-red-500 uppercase tracking-wide">
              Why it matters
            </span>
            <h2 className="mt-3 text-3xl sm:text-4xl font-bold tracking-tight text-white font-heading leading-tight">
              Why your business needs a website
            </h2>
            <p className="mt-4 text-lg text-slate-400 leading-relaxed">
              Being found online isn't optional anymore. If you're relying on
              social media alone — or you've no website at all — you're quietly
            turning customers away. Here's what a proper website does for a
            local business like yours.
            </p>
            <a
              href="#contact"
              className="mt-8 inline-flex items-center gap-2 bg-red-600 hover:bg-red-500 text-white font-semibold px-6 py-3 rounded-full transition-all hover:-translate-y-0.5"
            >
              Get your site started
            </a>
          </Reveal>

          <div className="lg:col-span-7 grid sm:grid-cols-2 gap-4">
            {reasons.map((r, i) => (
              <Reveal key={r.title} delay={(i % 2) * 0.1}>
                <div className="group h-full bg-white/[0.03] hover:bg-white/[0.06] border border-white/10 rounded-2xl p-6 transition-all duration-300 hover:-translate-y-1">
                  <div className="w-12 h-12 rounded-xl bg-red-600/15 text-red-500 flex items-center justify-center group-hover:bg-red-600 group-hover:text-white transition-colors">
                    <r.icon size={22} />
                  </div>
                  <h3 className="mt-5 font-semibold text-white leading-snug">
                    {r.title}
                  </h3>
                  <p className="mt-2 text-sm text-slate-400 leading-relaxed">
                    {r.text}
                  </p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}