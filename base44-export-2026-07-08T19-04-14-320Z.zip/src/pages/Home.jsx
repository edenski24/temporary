import React from "react";
import Navbar from "@/components/site/Navbar";
import Hero from "@/components/site/Hero";
import WhyWebsite from "@/components/site/WhyWebsite";
import Services from "@/components/site/Services";
import WhyChooseMe from "@/components/site/WhyChooseMe";
import FAQ from "@/components/site/FAQ";
import FinalCTA from "@/components/site/FinalCTA";
import Footer from "@/components/site/Footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground font-body antialiased">
      <Navbar />
      <main>
        <Hero />
        <WhyWebsite />
        <Services />
        <WhyChooseMe />
        <FAQ />
        <FinalCTA />
      </main>
      <Footer />
    </div>
  );
}